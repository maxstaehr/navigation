pq = PositionQueue();
pq.add([1 0 0], 1);
pq.add([2 0 0], 2);
pq.add([3 0 0], 3);
pq.add([4 0 0], 4);
pq.add([5 0 0], 5);

pq.posPast([0 0 0], 1);
